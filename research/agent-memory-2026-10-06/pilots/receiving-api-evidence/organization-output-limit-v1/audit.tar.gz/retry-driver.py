import pathlib,sys,json
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';p=base/'stage-two-v1/pass-2/ren-account'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
from fictional_model_client import Client
import durable_recall_pilot as pilot
from hermes_cli.auth import read_credential_pool
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
c=Client(base/'stage-two-organization-expanded-transport',repo/'docs/benchmarks/narrative-consolidation-cases.json',keys[0],base/'codex-native-probe-setup/tool-free-models.json',operation_output_limit=32768)
q=json.loads((p/'expanded-output-input.json').read_text());trace=pilot.Trace(p/'proposed/expanded-output-trace.json');trace.phase='consolidation_review'
r=c.chat('deepseek-flash',q['messages'],trace);pilot.save(p/'expanded-output-proposal.json',r);print(json.dumps(r,ensure_ascii=False,indent=2));print('proposal_sha256',pilot.digest(r))
