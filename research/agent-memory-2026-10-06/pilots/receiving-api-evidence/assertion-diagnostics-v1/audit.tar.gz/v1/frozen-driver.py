"""Finite, fixed fictional review diagnostics. Outside expectations never enter requests."""
from pathlib import Path
import json,sys,hashlib,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr, receiving_exchange as ex, receiving_codex_native as native
import durable_recall_pilot as pilot
out=base/'assertion-diagnostic-v1';out.mkdir(exist_ok=True)
def copy(x):return json.loads(json.dumps(x))
def packet(arm,index):
 row=json.loads((base/f'fresh-flash-pipeline-v5/{arm}/answers.json').read_text())[index]
 for p in (base/f'fresh-flash-pipeline-v5-transport/{arm}/requests').glob('*.json'):
  req=json.loads(p.read_text())
  if req['phase']=='narrative_generation':
   ctx=json.loads(req['messages'][1]['content'])
   if ctx.get('question')==row['question']:break
 else:raise ValueError('Original fictional context missing')
 candidate={k:copy(row['answer'][k])for k in ['receiving_body','claims']}
 evidence=pilot.answer_evidence(row['packs'],row['expanded'])
 return ctx,candidate,evidence
ctx,morning,evidence=packet('proposed',20)
correct=copy(morning);correct['claims'][1]['text']=correct['claims'][1]['text'].replace('about the porch speaker','through the porch speaker')
cases=[('faithful-channel',correct,ctx,evidence,[],[]),('invented-topic',morning,ctx,evidence,[1],[])]
for name,index,text in [
 ('wrong-participant',5,'Neri changed the lantern battery that morning.'),
 ('wrong-receipt-date',3,'I received the human\'s quiet-morning account through fixture:body:voice on 2026-09-18.'),
 ('invented-repair',6,'The battery change repaired the porch speaker.'),
 ('invented-current-capability',11,'In this voice body, I have physical sensors and actuators to test and repair the speaker.')]:
 c=copy(correct);c['claims'][index]['text']=text;cases.append((name,c,ctx,evidence,[index],[]))
ctx2,candidate2,evidence2=packet('baseline',4)
cases.append(('faithful-mixed-basis',candidate2,ctx2,evidence2,[],[]))
conditions=dict(procedure='assertions/v2',model='gpt-6.1-sol',effort='low',tools=False,native_memory=False,
 narrative_sha256=ex.checksum(Path(nr.__file__)),cases=len(cases),closing_comparison=False)
p=out/'conditions.json'
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
def run(case):
 name,candidate,context,evidence,unsupported,missing=case
 root=out/name;root.mkdir(exist_ok=True);trace=pilot.Trace(root/'trace.json');trace.phase='narrative_review'
 context=copy(context);context.update(candidate=candidate,review_protocol='assertions/v2')
 for r in context['evidence']:r['proof_passages']=nr.proof_passages(evidence[r['id']])
 messages=[dict(role='system',content=nr.ASSERTION_REVIEW),dict(role='user',content=json.dumps(context,ensure_ascii=False))]
 # Only actual evidence, binding, candidate and task schema are sent. Expectations remain in this local file.
 transport=ex.FileExchange(root,'low','low')
 try:
  try:raw=transport('gpt-6.1-sol',messages,trace)
  except ex.ResponsePending as pending:
   native.dispatch(Path(str(pending)),root,base/'codex-native-probe-setup/tool-free-models.json')
   raw=transport('gpt-6.1-sol',messages,trace)
  canonical=nr.passage_review(raw,candidate,evidence,'assertions')
  nr.review_shape(canonical,candidate,evidence,context['receiving_binding'],'assertions')
  bad=[r['index']for r in canonical['claims']if r['verdict']=='unsupported']
  result=dict(name=name,structure_valid=True,expected_unsupported=unsupported,actual_unsupported=bad,
   expected_missing=missing,actual_missing=canonical['missing'],matched=bad==unsupported and canonical['missing']==missing,
   candidate=candidate,canonical_review=canonical)
 except Exception as e:result=dict(name=name,structure_valid=False,error=str(e),matched=False)
 pilot.save(root/'outside-diagnostic.json',result)
 print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 results=list(pool.map(run,cases))
pilot.save(out/'results.json',results)
print('Bounded matched',sum(r['matched']for r in results),'/',len(results),flush=True)
