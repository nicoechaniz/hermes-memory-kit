"""One explicit two-arm closing comparison; no queue or automatic retry."""
import sys,json,pathlib,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot
import fictional_model_client as client_module
from hermes_cli.auth import read_credential_pool
fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json';transport=base/'closing-assertions-v1-transport'
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
catalog=base/'codex-native-probe-setup/tool-free-models.json'
def exact_raw_or_dispatch(path,root):
 if (transport/'stop-dispatch').exists():raise RuntimeError('Foreground operator stopped new dispatch; preserve pending work.')
 request=json.loads(path.read_text())
 for source in [base/'fresh-flash-pipeline-v5-transport']:
  for response_path in source.rglob('responses/'+path.name):
   old_request=response_path.parent.parent/'requests'/path.name
   if not old_request.exists()or json.loads(old_request.read_text())!=request:continue
   response=json.loads(response_path.read_text());receipt=json.loads(pathlib.Path(response['dispatch_receipt']).read_text())
   if receipt.get('state')!='completed'or receipt.get('request_sha256')!=path.stem or receipt.get('content')!=response.get('content'):continue
   if request['model']=='gpt-6.1-sol':
    if receipt.get('provider')!='openai-codex-native'or receipt.get('requested_model')!=request['model']or receipt.get('reasoning_effort')!='low'or receipt.get('catalog_sha256')!=hashlib.sha256(catalog.read_bytes()).hexdigest():continue
   elif receipt.get('parameters')!=client_module.api.parameters(request,'deepseek'):continue
   (root/'responses').mkdir(exist_ok=True);pilot.save(root/'responses'/path.name,response);return
 if request['model']=='gpt-6.1-sol':return client_module.native.dispatch(path,root,catalog)
 return client_module.api.dispatch(path,root,keys[0],'deepseek')
client=client_module.Client(transport,fixture,keys[0],catalog,review_protocol='assertions',dispatcher=exact_raw_or_dispatch)
pilot.chat=client.chat;original=pilot.narrative_recall.answer
def answer(*args,**kwargs):
 kwargs.update(review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded');return original(*args,**kwargs)
pilot.narrative_recall.answer=answer
frozen=dict(driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),client_conditions=json.loads((transport/'client-conditions.json').read_text()),
 formation='Same original v1 formation; source loss, real aged retrieval and new reader procedure. No selection recapture or private source access.',
 raw_reuse='Only complete identical original V5 fictional requests with observed model/parameters/content receipts. No verdict, answer checkpoint or revision budget imported.',
 scope='One complete closing comparison; original 18 cases/22 questions; new fixed-packet holdouts evaluated separately; no unattended queue or native memory.')
p=transport/'driver-conditions.json'
if p.exists():assert json.loads(p.read_text())==frozen
else:pilot.save(p,frozen)
sys.argv=['durable_recall_pilot','--out',str(base/'closing-assertions-v1'),'--model','deepseek-flash','--receiving-model','deepseek-flash','--corpus',str(fixture),'--review-capture','--narrative','--narrative-reasoning-effort','low','--narrative-reasoning-budget','none','--complete-diagnostics','--reuse-capture',str(base/'fresh-flash-pipeline-v1'),'--reuse-with-retrieval-upgrade']+sys.argv[1:]
pilot.main()
