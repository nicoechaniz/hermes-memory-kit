import pathlib,sys,json,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';out=base/'stage-two-v1/pass-1/tideatlas-project'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_organization_pilot as org,durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
value=org.read(out/'input.json');bad=org.read(out/'proposal.json');context=org.read(repo/'docs/benchmarks/narrative-consolidation-cases.json')['fixture_context']
value['receiving_binding']=dict(being=context['being'],receiving_body='fixture:body:voice',same_being_bodies=context['same_being_bodies'],source_network_access=False,repository_runtime_access=False,physical_sensors=False,physical_actuators=False,private_session_access=False,identity_note=context['identity_note']);pilot.save(out/'bound-input.json',value)
bound=dict(max_dispatches=1,new_input_sha256=org.digest(value),rejected_proposal_sha256=org.digest(bad),helper_sha256=hashlib.sha256(pathlib.Path(org.__file__).read_bytes()).hexdigest(),automatic_application=False)
p=out/'correction-bound.json'
if p.exists():assert org.read(p)==bound
else:pilot.save(p,bound)
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(base/'fresh-flash-pipeline-v3-transport',repo/'docs/benchmarks/narrative-consolidation-cases.json',keys[0],base/'codex-native-probe-setup/tool-free-models.json')
messages=org.proposal_messages(value,'tideatlas-project',1);messages[0]['content']+='\nCorrect the supplied candidate once. Preserve this being\'s own source-established renderer and map collaboration under the supplied fictional membership; receiving a human report remains distinct from participation. This is a compact current project account with recognition, own role, dated outcome/limits and world pointers; full episodes stay preserved through the actual supports. Remove repeated event scaffolding without inventing occurrence dates or a successful handover. Return the complete contractual object.'
messages[1]['content']=json.dumps(dict(**value,organization_pass=1,account_phase='tideatlas-project',rejected_candidate=bad,observed_errors=['The candidate recasts our source-established code-body contribution as an unnamed source\'s code body/group; explicit membership context is now supplied.','The current account repeats every source-event scaffold instead of a compact dated project synopsis linked to full episodes.']),ensure_ascii=False)
trace=pilot.Trace(out/'proposed/correction-trace.json');trace.phase='consolidation_review'
a=client.chat('deepseek-flash',messages,trace);pilot.save(out/'corrected-proposal.json',a);print(json.dumps(a,ensure_ascii=False,indent=2));print('reviewable_sha256',org.digest(a))
