"""Cold fictional recall after a named immutable organization snapshot."""
import sys,pathlib,json,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';stage=sys.argv[1]
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
qualification=json.loads((base/'fresh-flash-qualification.json').read_text());assert qualification['fresh_formation_qualified']
fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json';source=base/'stage-two-v1'/('source-'+stage);assert source.is_dir()
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(base/'fresh-flash-pipeline-v3-transport',fixture,keys[0],base/'codex-native-probe-setup/tool-free-models.json');pilot.chat=client.chat
original=pilot.narrative_recall.answer
def answer(*args,**kwargs):
 kwargs.update(review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='passages',source_representation='decoded');return original(*args,**kwargs)
pilot.narrative_recall.answer=answer
out=base/'stage-two-v1'/('recall-'+stage)
p=out.with_name(out.name+'-driver-conditions.json');conditions=dict(driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),source=stage,qualification=qualification,client_conditions=json.loads((client.root/'client-conditions.json').read_text()),raw_response_reuse='Only exact identical requests; all results structurally and semantically evaluated anew, no accepted-answer/budget imports.')
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
sys.argv=['durable_recall_pilot','--out',str(out),'--model','deepseek-flash','--receiving-model','deepseek-flash','--corpus',str(fixture),'--review-capture','--narrative','--narrative-reasoning-effort','low','--narrative-reasoning-budget','none','--complete-diagnostics','--reuse-capture',str(source),'--reuse-with-retrieval-upgrade']+sys.argv[2:]
pilot.main()
