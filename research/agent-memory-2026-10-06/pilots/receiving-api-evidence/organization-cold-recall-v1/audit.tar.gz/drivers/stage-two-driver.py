import sys,json,pathlib,hashlib,shutil
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';out=base/'stage-two-v1';canon=out/'canon';fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json';qualification=base/'fresh-flash-qualification.json'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_organization_pilot as org
import durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool

def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);pilot.save(p,x)
def read(p):return json.loads(p.read_text())
def checked_memory():return org.scoped_memory(canon,fixture,qualification)
def unbound_phase_input(memory,phase):
 targets=read(out/'targets.json') if (out/'targets.json').exists() else {}
 target=targets.get(phase)
 if phase in ['project','understanding']:
  return org.proposal_input(canon,memory,phase,target,targets.get('project'))
 if phase not in ['tideatlas-project','ren-account']:raise ValueError('unknown bounded account phase')
 entries=read(canon/'proposed/capture.json');capture=next(c for c in entries if c['case_id']=='failed-chart-handover')
 ids=[r['chapter_id'] for r in capture['receipt']['records'].values()]
 episode=next(cid for cid in ids if memory._read_chapter(cid)['engram_type']=='episodic')
 if target is None:
  target=next(cid for cid in ids if memory._read_chapter(cid)['engram_type']=='semantic' and
              ('Ren Nadir' in memory._read_chapter(cid)['title'])==(phase=='ren-account'))
 return dict(manifest=org.consolidationctl.preview([episode],memory,profile='native'),current_account=memory._read_chapter(target),purpose=('A compact TideAtlas project account: own contribution, dated collaboration/result and world pointers; retain uncertainty.' if phase=='tideatlas-project' else 'A compact Ren Nadir relationship account with known name/account, our attributed collaboration and its dated outcomes.'))

def phase_input(memory,phase):
 value=unbound_phase_input(memory,phase)
 context=read(fixture)['fixture_context']
 value['receiving_binding']=dict(being=context['being'],receiving_body='fixture:body:voice',same_being_bodies=context['same_being_bodies'],source_network_access=False,repository_runtime_access=False,physical_sensors=False,physical_actuators=False,private_session_access=False,identity_note=context['identity_note'])
 return value

action=sys.argv[1]
if action=='clone':
 if not read(qualification).get('fresh_formation_qualified'):raise ValueError('fresh formation is not qualified')
 src=base/'fresh-flash-pipeline-v3';assert not canon.exists();canon.mkdir()
 shutil.copy2(src/'conditions.json',canon/'conditions.json')
 for arm in ['baseline','proposed']:
  target=canon/arm;target.mkdir();(target/'memory').mkdir()
  for name in ['capture.json','selected-canon.json']:shutil.copy2(src/arm/name,target/name)
  org.verified_snapshot(src/arm/'memory/library.db',target/'memory/library.db')
 memory=checked_memory();save(out/'original-rows.json',pilot.current_records(memory))
 with memory.connect() as con:save(out/'original-history.json',[dict(r) for r in con.execute('SELECT * FROM chapter_revisions')])
 save(out/'conditions.json',dict(driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),helper_sha256=hashlib.sha256(pathlib.Path(org.__file__).read_bytes()).hexdigest(),correction_sha256=hashlib.sha256((out/'correction-fixture.json').read_bytes()).hexdigest(),native_apis_unchanged=True,passes=3,account_phases=['project','tideatlas-project','ren-account','understanding'],qualification=read(qualification),prompt_rubrics=False))
 print('verified fictional canonical copies prepared');sys.exit()
memory=checked_memory()
if action=='prepare':
 phase,n=sys.argv[2],int(sys.argv[3]);directory=out/f'pass-{n}'/phase;directory.mkdir(parents=True,exist_ok=True)
 value=phase_input(memory,phase);save(directory/'input.json',value)
 keys=[r['access_token'] for r in read_credential_pool('deepseek') if r.get('source')=='manual' and r.get('access_token')];assert len(keys)==1
 client=Client(base/'fresh-flash-pipeline-v3-transport',fixture,keys[0],base/'codex-native-probe-setup/tool-free-models.json')
 # Shared trace parent retains exact-input response reuse across stages.
 tracepath=directory/'proposed/trace.json';tracepath.parent.mkdir();trace=pilot.Trace(tracepath);trace.phase='consolidation'
 candidate=client.chat('deepseek-flash',org.proposal_messages(value,phase,n),trace);save(directory/'candidate.json',candidate)
 trace.phase='consolidation_review'
 messages=org.proposal_messages(value,phase,n);messages[0]['content']+='\nReview this candidate against actual supplied supports. Preserve source roles and dates, every required qualifier and current-account identity; remove duplication and unsupported claims. Return the complete corrected decision and supports_by_record.'
 messages[1]['content']=json.dumps(dict(**value,organization_pass=n,account_phase=phase,candidate=candidate),ensure_ascii=False)
 proposal=client.chat('deepseek-flash',messages,trace);save(directory/'proposal.json',proposal)
 print(json.dumps(proposal,ensure_ascii=False,indent=2));print('proposal_sha256',org.digest(proposal));sys.exit()
if action=='apply':
 phase,n,sha=sys.argv[2],int(sys.argv[3]),sys.argv[4];directory=out/f'pass-{n}'/phase
 value=read(directory/'input.json');proposal=read(directory/'proposal.json')
 result=org.reviewed_apply(memory,value,proposal,directory,phase=phase,pass_number=n,reviewed_sha256=sha)
 targets=read(out/'targets.json') if (out/'targets.json').exists() else {};targets[phase]=result['account']['id'];save(out/'targets.json',targets)
 save(directory/'preservation.json',org.preservation(memory,read(out/'original-rows.json'),read(out/'original-history.json')))
 print(json.dumps(dict(id=result['account']['id'],revision=result['account']['revision'],replay=True,rollback=True)));sys.exit()
if action=='replay':
 save(out/'replay.json',org.replay_capture(canon,memory,fixture));print('18 exact inputs/decisions replayed; canonical and ledger unchanged');sys.exit()
if action=='correct':
 targets=read(out/'targets.json');capture=next(c for c in read(canon/'proposed/capture.json') if c['case_id']=='project-status-change');target=next(r['chapter_id'] for r in capture['receipt']['records'].values() if memory._read_chapter(r['chapter_id'])['engram_type']=='episodic')
 result=org.apply_correction(memory,target,read(out/'correction-fixture.json'),[targets['project'],targets['understanding']],out/'correction')
 save(out/'correction/preservation.json',org.preservation(memory,read(out/'original-rows.json'),read(out/'original-history.json')));print(json.dumps(result['stale_dependents'],indent=2));sys.exit()
if action=='stage-source':
 name=sys.argv[2];stage=out/('source-'+name);assert not stage.exists();stage.mkdir()
 shutil.copy2(canon/'conditions.json',stage/'conditions.json')
 for arm in ['baseline','proposed']:
  target=stage/arm;target.mkdir();(target/'memory').mkdir()
  shutil.copy2(canon/arm/'capture.json',target/'capture.json');m=memory if arm=='proposed' else pilot.memory_at(canon/arm/'memory')
  org.verified_snapshot(m.DB_PATH,target/'memory/library.db');save(target/'selected-canon.json',pilot.current_records(m))
  # Exact initial formation trace is retained as formation provenance, not new calls.
  for filename in ['trace.json','embedding-trace.json']:shutil.copy2(base/'fresh-flash-pipeline-v3'/arm/filename,target/filename)
 save(stage/'organization-provenance.json',dict(stage=name,canon=str(canon),originals_preservation=org.preservation(memory,read(out/'original-rows.json'),read(out/'original-history.json')),targets=read(out/'targets.json')))
 print(stage);sys.exit()
raise ValueError('unknown finite operation')
