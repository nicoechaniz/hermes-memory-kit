"""One bounded source-grounded correction; never apply it automatically."""
import pathlib,sys,json,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';out=base/'stage-two-v1/pass-1/project'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_organization_pilot as org,durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
value=json.loads((out/'input.json').read_text());bad=json.loads((out/'proposal.json').read_text())
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(base/'fresh-flash-pipeline-v3-transport',repo/'docs/benchmarks/narrative-consolidation-cases.json',keys[0],base/'codex-native-probe-setup/tool-free-models.json')
authority=out/'correction-bound.json'
bound=dict(max_correction_dispatches=1,input_sha256=hashlib.sha256((out/'input.json').read_bytes()).hexdigest(),rejected_proposal_sha256=hashlib.sha256((out/'proposal.json').read_bytes()).hexdigest(),helper_sha256=hashlib.sha256(pathlib.Path(org.__file__).read_bytes()).hexdigest(),automatic_application=False)
if authority.exists():assert json.loads(authority.read_text())==bound
else:pilot.save(authority,bound)
messages=org.proposal_messages(value,'project',1)
messages[0]['content']+='\nCorrect the supplied candidate, returning the complete contractual object. The structural record field is key with literal value account, and supports_by_record uses that same literal key. Preserve all actually supplied meaning; do not turn a report receipt year into an occurrence year in raw or summary. Inspect summary separately from raw.'
messages[1]['content']=json.dumps(dict(**value,organization_pass=1,account_phase='project',rejected_candidate=bad,observed_errors=['Record has account instead of key:account; supports_by_record is keyed by a project name instead of account.','The summary expands source month/day occurrences to full years that only receipt headers supply.']),ensure_ascii=False)
trace=pilot.Trace(out/'proposed/correction-trace.json');trace.phase='consolidation_review'
a=client.chat('deepseek-flash',messages,trace);pilot.save(out/'corrected-proposal.json',a)
print(json.dumps(a,ensure_ascii=False,indent=2));print('reviewable_sha256',org.digest(a))
