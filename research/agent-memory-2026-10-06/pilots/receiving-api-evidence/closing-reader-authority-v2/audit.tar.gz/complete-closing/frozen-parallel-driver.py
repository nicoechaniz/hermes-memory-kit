"""Complete closing packages with the bounded corrected source interpretation."""
from pathlib import Path
import sys,json,hashlib,concurrent.futures,threading
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot,fictional_model_client as cm
from hermes_cli.auth import read_credential_pool
out=base/'closing-reader-authority-v2';out.mkdir(exist_ok=True)
catalog=base/'codex-native-probe-setup/tool-free-models.json';fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json'
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
sources=[out/'transport',base/'closing-unknown-premises-v1/transport',base/'stage-two-unknown-premises-v1-transport',base/'reader-rules-diagnostic-v1',base/'reader-authority-diagnostic-v2',base/'closing-medium-joint-v1/transport',base/'stage-two-medium-joint-v1-transport',base/'unknown-premises-diagnostic-v1',base/'unknown-premises-family-diagnostic-v1',base/'closing-temporal-source-v1/transport',base/'medium-modifier-scope-diagnostic-v1',base/'closing-source-frame-v1/transport',base/'temporal-evidence-diagnostic-v1',base/'closing-receipts-v2/transport',base/'closing-assertions-v1-transport',base/'stage-two-receipts-v2-transport',base/'stage-two-assertions-v1-transport',base/'fresh-flash-pipeline-v5-transport',base/'stage-two-cached-v5-transport',base/'report-referents-diagnostic-v1']
index={}
for source in sources:
 for response in source.rglob('responses/*.json'):index.setdefault(response.name,[]).append(response)
def dispatch(path,root):
 if(out/'stop-dispatch').exists():raise RuntimeError('Stopped corrected closing dispatch; preserve pending work.')
 request=json.loads(path.read_text())
 for response_path in index.get(path.name,[]):
  original=response_path.parent.parent/'requests'/path.name
  if not original.exists()or json.loads(original.read_text())!=request:continue
  response=json.loads(response_path.read_text());receipt=json.loads(Path(response['dispatch_receipt']).read_text())
  if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
  if request['model']=='gpt-6.1-sol':
   if receipt.get('provider')!='openai-codex-native'or receipt.get('reasoning_effort')!=request['reasoning_effort']or receipt.get('catalog_sha256')!=cm.api.exchange.checksum(catalog):continue
  elif receipt.get('parameters')!=cm.api.parameters(request,'deepseek'):continue
  target=root/'responses'/path.name;target.parent.mkdir(exist_ok=True);pilot.save(target,response);return
 if request['model']=='gpt-6.1-sol':return cm.native.dispatch(path,root,catalog)
 return cm.api.dispatch(path,root,keys[0],'deepseek')
client=cm.Client(out/'transport',fixture,keys[0],catalog,review_protocol='assertions',review_effort='medium',dispatcher=dispatch)
conditions=dict(driver_sha256=cm.api.exchange.checksum(Path(__file__)),client=json.loads((client.root/'client-conditions.json').read_text()),original_packages='closing-assertions-v1; original formation/retrieval/stress unchanged',source_referents_protocol='report-referents/v2',world_pointer_protocol='balanced-pointer/v2',temporal_evidence_protocol='native-timestamp-with-receipt-scope/v1',pilot_sha256=cm.api.exchange.checksum(Path(pilot.__file__)),native_memory=False,stage_two_complete=False,joint_support_protocol='memory-and-binding/v1',review_effort='medium',unknown_premises_protocol='positive-presuppositions/v1')
p=out/'conditions.json'
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
for name in ['narrative_recall.py','durable_recall_pilot.py','fictional_model_client.py','receiving_exchange.py','receiving_codex_native.py','receiving_text_api.py']:
 target=out/('frozen-'+name);content=(repo/'research/agent-memory-2026-10-06/pilots'/name).read_bytes()
 if target.exists():assert target.read_bytes()==content
 else:target.write_bytes(content)
(out/'frozen-parallel-driver.py').write_bytes(Path(__file__).read_bytes())
lock=threading.Lock()
originals={arm:json.loads((base/'closing-assertions-v1'/arm/'answers.json').read_text())for arm in ['baseline','proposed']}
results={arm:{}for arm in originals}
for arm in originals:
 p=out/arm/'answers.json'
 if p.exists():results[arm]={i:r for i,r in enumerate(json.loads(p.read_text()))}
def run(task):
 arm,i=task;r=originals[arm][i];folder=out/arm;folder.mkdir(exist_ok=True)
 calls=out/('calls-'+arm+'-'+str(i));calls.mkdir(exist_ok=True)
 trace=pilot.Trace(calls/'trace.json');trace.phase='recall';trace.narrative_reasoning_effort='low';trace.narrative_reasoning_budget=None;trace.narrative_max_tokens=12000
 old=json.loads(r['narrative_attempts']['progress']['messages'][1]['content']);evidence=pilot.answer_evidence(r['packs'],r['expanded'],True);binding=old['receiving_binding']
 checkpoint=folder/f'question-{i}.json';pending=json.loads(checkpoint.read_text())if checkpoint.exists()else{}
 try:
  value=pilot.narrative_recall.answer('deepseek-flash',r['question'],evidence,binding,trace,pending,checkpoint,client.chat,pilot.save,review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded',preserve_citation_receipts=True,clarify_deixis=True,allow_joint_support=True,review_effort='medium',check_unknown_premises=True)
  pilot.verify_narrative_answer(value,pending,evidence,binding)
 except(pilot.narrative_recall.NarrativeRejected,ValueError)as e:
  value=dict(pending['narrative']['generations'][-1],text=' '.join(c['text']for c in pending['narrative']['generations'][-1]['claims']),operational_status='rejected',error=str(e))
 row=dict(case_id=r['case_id'],question=r['question'],answer=value,narrative_attempts=pending['narrative'],source_package_sha256=pilot.digest(dict(question=r['question'],evidence=evidence,binding=binding)),original_answer_index=i)
 pilot.save(folder/f'answer-{i}.json',row)
 with lock:
  results[arm][i]=row
  prefix=[]
  for j in range(22):
   if j not in results[arm]:break
   prefix.append(results[arm][j])
  pilot.save(folder/'answers.json',prefix)
 print(arm,i,value.get('operational_status','accepted'),'claims',len(value['claims']),flush=True)
 return arm,i
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:list(pool.map(run,[(arm,i)for i in range(22)for arm in ['baseline','proposed']]))
assert all(len(v)==22 for v in results.values())
print('Complete closing unknown-premise packages; outside assessment still required.',flush=True)
