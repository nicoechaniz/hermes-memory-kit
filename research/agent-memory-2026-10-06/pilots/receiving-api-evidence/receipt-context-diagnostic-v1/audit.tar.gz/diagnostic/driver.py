"""Bounded same-package consumption of actual existing model receipts only."""
import json,pathlib,sys,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import durable_recall_pilot as pilot
from fictional_model_client import Client
import fictional_model_client as cm
r=json.loads((base/'stage-two-v1/recall-pass-1-understanding-assertions-v1/proposed/answers.json').read_text())[5]
oldctx=json.loads(r['narrative_attempts']['progress']['messages'][1]['content']);evidence=pilot.answer_evidence(r['packs'],r['expanded']);binding=oldctx['receiving_binding']
assert pilot.narrative_recall.supplied_context(r['question'],evidence,binding,'decoded')==oldctx
catalog=base/'codex-native-probe-setup/tool-free-models.json';root=base/'receipt-context-diagnostic-v1'
def existing_only(path,root):
 request=json.loads(path.read_text())
 for source in [base/'stage-two-assertions-v1-transport/pass-1-understanding',base/'fresh-flash-pipeline-v5-transport']:
  for response_path in source.rglob('responses/'+path.name):
   original_request=response_path.parent.parent/'requests'/path.name
   if not original_request.exists()or json.loads(original_request.read_text())!=request:continue
   response=json.loads(response_path.read_text());receipt=json.loads(pathlib.Path(response['dispatch_receipt']).read_text())
   if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
   if request['model']=='gpt-6.1-sol':
    if receipt.get('provider')!='openai-codex-native'or receipt.get('reasoning_effort')!='low'or receipt.get('requested_model')!=request['model']or receipt.get('catalog_sha256')!=hashlib.sha256(catalog.read_bytes()).hexdigest():continue
   elif receipt.get('parameters')!=cm.api.parameters(request,'deepseek'):continue
   (root/'responses').mkdir(exist_ok=True);pilot.save(root/'responses'/path.name,response);return
 raise RuntimeError('This bounded diagnostic forbids a new model dispatch.')
client=Client(root/'transport',repo/'docs/benchmarks/narrative-consolidation-cases.json','',catalog,review_protocol='assertions',dispatcher=existing_only)
(root/'proposed').mkdir(exist_ok=True);trace=pilot.Trace(root/'proposed/trace.json');trace.phase='recall';trace.narrative_reasoning_effort='low';trace.narrative_reasoning_budget=None;trace.narrative_max_tokens=12000
pending={};result=pilot.narrative_recall.answer('deepseek-flash',r['question'],evidence,binding,trace,pending,root/'pending.json',client.chat,pilot.save,review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded',preserve_citation_receipts=True)
pilot.verify_narrative_answer(result,pending,evidence,binding)
assert pending['narrative']['accepted']==r['narrative_attempts']['generations'][2]
assert len(pending['narrative']['reviews'])==2 and pending['narrative']['progress']['revision']==1
assert len(pending['narrative']['generations'])==3
assert all('our shared intention'not in c['text']for c in result['claims'])
pilot.save(root/'answer.json',result);pilot.save(root/'input.json',dict(question=r['question'],evidence=evidence,binding=binding))
# Preserve the rejected drift and native verdict; receipts do not change judgment.
bad=r['narrative_attempts']['reviews'][2]['canonical_review'];assert bad['claims'][12]['verdict']=='unsupported'
pilot.save(root/'rejected-comparator.json',dict(candidate=r['narrative_attempts']['generations'][3],canonical_review=bad,original_status=r['answer']['operational_status']))
print('Same package: faithful first semantic revision accepted; original later ownership error remains rejected. Zero new model calls; one revision/review pair avoided; actual receipt dates retained as source context.')
print(json.dumps([(c['text'],c['basis'])for c in result['claims']],ensure_ascii=False));print('citation receipts',json.dumps(result['citation_receipts'],ensure_ascii=False))
