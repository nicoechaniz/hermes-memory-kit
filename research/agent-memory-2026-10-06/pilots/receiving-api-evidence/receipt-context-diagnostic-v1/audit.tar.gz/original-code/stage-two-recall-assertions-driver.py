"""Cold fictional recall after a named immutable organization snapshot."""
import sys,pathlib,json,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';stage=sys.argv[1]
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
qualification=json.loads((repo/'research/agent-memory-2026-10-06/pilots/receiving-api-evidence/closing-assertions-v1/outside-assessment.json').read_text());assert qualification['fresh_formation_qualified'] and qualification['baseline_receiving_gate'];qualification={k:qualification[k]for k in ['fresh_formation_qualified','baseline_receiving_gate','proposed_receiving_gate','claims_assessed','positive_delivered_requirements_met']}
fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json';source=base/'stage-two-v1'/('source-'+stage);assert source.is_dir()
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
import fictional_model_client as client_module
def completed_exact_dispatch(path,root):
 request=json.loads(path.read_text());sources=[base/'closing-assertions-v1-transport',base/'stage-two-assertions-v1-transport',base/'fresh-flash-pipeline-v5-transport',base/'stage-two-cached-v5-transport']
 if (base/'stage-two-assertions-v1-transport/stop-dispatch').exists():raise RuntimeError('Human-directed foreground stop; preserve this pending request.')
 for source in sources:
  for response_path in source.rglob('responses/'+path.name):
   if response_path.parent.parent.resolve()==root.resolve():continue
   request_path=response_path.parent.parent/'requests'/path.name
   if not request_path.exists()or json.loads(request_path.read_text())!=request:continue
   response=json.loads(response_path.read_text());receipt_path=pathlib.Path(response['dispatch_receipt']);receipt=json.loads(receipt_path.read_text())
   if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
   if request['model']=='gpt-6.1-sol':
    if receipt.get('provider')!='openai-codex-native'or receipt.get('requested_model')!=request['model']or receipt.get('reasoning_effort')!='low'or receipt.get('catalog_sha256')!=hashlib.sha256((base/'codex-native-probe-setup/tool-free-models.json').read_bytes()).hexdigest():continue
   elif receipt.get('parameters')!=client_module.api.parameters(request,'deepseek'):continue
   target=root/'responses'/path.name;target.parent.mkdir(exist_ok=True);pilot.save(target,response)
   return
 if request['model']=='gpt-6.1-sol':return client_module.native.dispatch(path,root,base/'codex-native-probe-setup/tool-free-models.json')
 return client_module.api.dispatch(path,root,keys[0],'deepseek')
client=Client(base/'stage-two-assertions-v1-transport'/stage,fixture,keys[0],base/'codex-native-probe-setup/tool-free-models.json',review_protocol='assertions',dispatcher=completed_exact_dispatch);pilot.chat=client.chat
original=pilot.narrative_recall.answer
def answer(*args,**kwargs):
 kwargs.update(review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded');return original(*args,**kwargs)
pilot.narrative_recall.answer=answer
out=base/'stage-two-v1'/('recall-'+stage+'-assertions-v1')
p=out.with_name(out.name+'-driver-conditions.json');conditions=dict(driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),source=stage,qualification=qualification,closing_narrative_qualification=True,stage_two_complete=False,client_conditions=json.loads((client.root/'client-conditions.json').read_text()),raw_response_reuse='Only exact complete identical fictional requests with unchanged actual role parameters and validated physical receipts across these fictional transport roots. No accepted answers/checkpoints, verdict approval or repair-budget imports; every response consumed and evaluated anew; new dispatches are explicit and separately counted.')
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
sys.argv=['durable_recall_pilot','--out',str(out),'--model','deepseek-flash','--receiving-model','deepseek-flash','--corpus',str(fixture),'--review-capture','--narrative','--narrative-reasoning-effort','low','--narrative-reasoning-budget','none','--complete-diagnostics','--reuse-capture',str(source),'--reuse-with-retrieval-upgrade']+sys.argv[2:]
pilot.main()
