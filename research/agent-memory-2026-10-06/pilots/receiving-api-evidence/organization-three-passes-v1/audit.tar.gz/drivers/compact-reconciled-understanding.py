import sys,json,pathlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_organization_pilot as org, durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
phase=base/'stage-two-v1/pass-4/understanding'
value=json.loads((phase/'input.json').read_text());candidate=json.loads((phase/'proposal.json').read_text())
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(base/'stage-two-organization-v5-transport',repo/'docs/benchmarks/narrative-consolidation-cases.json',keys[0],base/'codex-native-probe-setup/tool-free-models.json',operation_output_limit=32768)
messages=org.proposal_messages(value,'understanding',4)
messages[0]['content']+='\nOne bounded correction of the candidate: it repeats linked account timelines and exceeds the existing compactness aim. Keep only the learned method and origin, short dated illustrative actual outcomes for each application, attribution/limits and evidence pointers. Original linked supports preserve full participant inventories and chronology. Do not repeat those inventories here. Aim for 150–250 words in raw, preserving corrected partial outcomes and unknowns. Return the complete native decision and supports_by_record. No optional summary, new facts, episode removal or new supports.'
messages[1]['content']=json.dumps(dict(**value,organization_pass=4,account_phase='understanding',candidate=candidate),ensure_ascii=False)
trace=pilot.Trace(phase/'compact-correction-trace.json');trace.phase='consolidation_review'
result=client.chat('deepseek-flash',messages,trace);pilot.save(phase/'compact-correction.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2));print('proposal_sha256',org.digest(result))
