"""One source-attribution diagnostic, with expectations kept outside receivers."""
from pathlib import Path
import json,sys,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr, receiving_exchange as ex, receiving_codex_native as native
import durable_recall_pilot as pilot
out=base/'report-referents-diagnostic-v1';out.mkdir(exist_ok=True)
def copy(x):return json.loads(json.dumps(x))
def actual(root,index):
 row=json.loads((root/'proposed/answers.json').read_text())[index]
 old=json.loads(row['narrative_attempts']['progress']['messages'][1]['content'])
 package=row if 'packs' in row else json.loads((base/'closing-assertions-v1/proposed/answers.json').read_text())[index]
 ev=pilot.answer_evidence(package['packs'],package['expanded']);binding=old['receiving_binding']
 cand=copy(row['narrative_attempts']['accepted'])
 return row['question'],ev,binding,cand
q,ev,binding,bad=actual(base/'stage-two-v1/recall-pass-1-understanding-receipts-v2',7)
assert bad['claims'][6]['text']=='As of that report, the reporter and I had not contacted the group.'
faithful=copy(bad);faithful['claims'][6]['text']='The report says "we" had not contacted the group; it does not identify all members of that group.'
cases=[('ambiguous-group-resolved',q,ev,binding,bad,[6]),('ambiguous-group-preserved',q,ev,binding,faithful,[])]
q2,ev2,binding2,shared=actual(base/'closing-receipts-v2',20)
cases.append(('faithful-shared-conversation',q2,ev2,binding2,shared,[]))
for name,quote,claim in [
 ('explicit-reported-participation','Yesterday you held the receiver while I read the frequency. Neither of us contacted the repair group. By us I mean you and me.', 'The human reported that I held the receiver while they read the frequency; neither of us contacted the repair group.'),
 ('explicit-noncontact-with-absent-encounter','You were not at my meeting with Leto. You and I have not contacted the repair group about it.', 'The human reported meeting Leto without me, and explicitly said that they and I had not contacted the repair group about it.')]:
 text='Human report; source fictional-explicit-membership; received 2026-09-17 through fixture:body:code:\n'+json.dumps(quote)
 evidence={1:{'text':text}}
 candidate=dict(receiving_body=binding['receiving_body'],claims=[dict(text=claim,support=[1],basis='memory',facet='limits')])
 cases.append((name,'What participation is established by this report?',evidence,binding,candidate,[]))
conditions=dict(model='gpt-6.1-sol',effort='low',source_referents_protocol='report-deixis/v1',narrative_sha256=ex.checksum(Path(nr.__file__)),cases=len(cases),tools_allowed=False,native_memory_allowed=False,closing_comparison=False)
path=out/'conditions.json'
if path.exists():assert json.loads(path.read_text())==conditions
else:pilot.save(path,conditions)
(out/'frozen-driver.py').write_bytes(Path(__file__).read_bytes());(out/'frozen-narrative_recall.py').write_bytes(Path(nr.__file__).read_bytes())
def run(case):
 name,q,evidence,binding,candidate,expected=case;root=out/name;root.mkdir(exist_ok=True)
 ctx=nr.supplied_context(q,evidence,binding,'decoded',True);ctx.update(candidate=candidate,review_protocol='assertions/v2')
 for row in ctx['evidence']:row['proof_passages']=nr.proof_passages(evidence[row['id']])
 trace=pilot.Trace(root/'trace.json');trace.phase='narrative_review'
 messages=[dict(role='system',content=nr.ASSERTION_REVIEW),dict(role='user',content=json.dumps(ctx,ensure_ascii=False))]
 transport=ex.FileExchange(root,'low','low')
 try:
  try:raw=transport('gpt-6.1-sol',messages,trace)
  except ex.ResponsePending as pending:
   native.dispatch(Path(str(pending)),root,base/'codex-native-probe-setup/tool-free-models.json')
   raw=transport('gpt-6.1-sol',messages,trace)
  canonical=nr.passage_review(raw,candidate,evidence,'assertions');nr.review_shape(canonical,candidate,evidence,binding,'assertions')
  bad=[r['index']for r in canonical['claims']if r['verdict']=='unsupported']
  result=dict(name=name,structure_valid=True,expected_unsupported=expected,actual_unsupported=bad,matched=bad==expected,actual_missing=canonical['missing'],candidate=candidate,canonical_review=canonical)
 except Exception as e:result=dict(name=name,structure_valid=False,error=str(e),matched=False)
 pilot.save(root/'outside-diagnostic.json',result)
 print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(run,cases))
pilot.save(out/'results.json',results)
print('Attribution decisions matched:',sum(r['matched']for r in results),'/',len(results),flush=True)
