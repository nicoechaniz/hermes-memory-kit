"""One further observed attribution error: reported group intention versus ours."""
from pathlib import Path
import json,sys
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr,receiving_exchange as ex,receiving_codex_native as native,durable_recall_pilot as pilot
row=json.loads((base/'stage-two-v1/recall-pass-1-understanding-receipts-v2/proposed/answers.json').read_text())[10]
evidence=pilot.answer_evidence(row['packs'],row['expanded']);binding=json.loads(row['narrative_attempts']['progress']['messages'][1]['content'])['receiving_binding'];candidate=row['narrative_attempts']['accepted']
root=base/'report-referents-diagnostic-v1/reported-group-intention';root.mkdir(exist_ok=True)
ctx=nr.supplied_context(row['question'],evidence,binding,'decoded',True);ctx.update(candidate=candidate,review_protocol='assertions/v2')
for r in ctx['evidence']:r['proof_passages']=nr.proof_passages(evidence[r['id']])
trace=pilot.Trace(root/'trace.json');trace.phase='narrative_review'
messages=[dict(role='system',content=nr.ASSERTION_REVIEW),dict(role='user',content=json.dumps(ctx,ensure_ascii=False))]
transport=ex.FileExchange(root,'low','low')
try:raw=transport('gpt-6.1-sol',messages,trace)
except ex.ResponsePending as pending:
 native.dispatch(Path(str(pending)),root,base/'codex-native-probe-setup/tool-free-models.json');raw=transport('gpt-6.1-sol',messages,trace)
canonical=nr.passage_review(raw,candidate,evidence,'assertions');nr.review_shape(canonical,candidate,evidence,binding,'assertions')
bad=[r['index']for r in canonical['claims']if r['verdict']=='unsupported']
result=dict(name='reported-group-intention',structure_valid=True,expected_unsupported=[3],actual_unsupported=bad,matched=bad==[3],actual_missing=canonical['missing'],candidate=candidate,canonical_review=canonical)
pilot.save(root/'outside-diagnostic.json',result);pilot.save(root/'conditions.json',dict(followup_reason='Outside inspection of a second actual accepted source-role error; same source frame must reject adoption of a human group intention.',model='gpt-6.1-sol',effort='low',tools=False,native_memory=False,narrative_sha256=ex.checksum(Path(nr.__file__))))
(root/'frozen-driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True)
