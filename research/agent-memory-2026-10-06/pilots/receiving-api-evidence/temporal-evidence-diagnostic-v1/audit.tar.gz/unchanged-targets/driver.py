"""All original closing packages; exact raw receipts only, no new inference."""
import json,pathlib,sys,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import durable_recall_pilot as pilot
import fictional_model_client as cm
catalog=base/'codex-native-probe-setup/tool-free-models.json';root=base/'unchanged-target-source-frame-v1'
def existing_only(path,root):
 request=json.loads(path.read_text())
 for source in [base/'stage-target-receipts-v2/transport',base/'closing-receipts-v2/transport',base/'closing-assertions-v1-transport',base/'stage-two-assertions-v1-transport',base/'fresh-flash-pipeline-v5-transport']:
  for response_path in source.rglob('responses/'+path.name):
   original_request=response_path.parent.parent/'requests'/path.name
   if not original_request.exists()or json.loads(original_request.read_text())!=request:continue
   response=json.loads(response_path.read_text());receipt=json.loads(pathlib.Path(response['dispatch_receipt']).read_text())
   if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
   if request['model']=='gpt-6.1-sol':
    if receipt.get('provider')!='openai-codex-native'or receipt.get('reasoning_effort')!='low'or receipt.get('requested_model')!=request['model']or receipt.get('catalog_sha256')!=hashlib.sha256(catalog.read_bytes()).hexdigest():continue
   elif receipt.get('parameters')!=cm.api.parameters(request,'deepseek'):continue
   (root/'responses').mkdir(exist_ok=True);pilot.save(root/'responses'/path.name,response);return
 raise RuntimeError('No new model dispatch permitted in complete package requalification.')
client=cm.Client(root/'transport',repo/'docs/benchmarks/narrative-consolidation-cases.json','',catalog,review_protocol='assertions',dispatcher=existing_only)
stages=['pass-1-tideatlas','pass-1-ren','pass-2-tideatlas','pass-2-ren','pass-3-tideatlas','pass-3-ren']
for stage,arm in [(s,a)for s in stages for a in ['baseline','proposed']]:
 folder=root/stage/arm;folder.mkdir(parents=True,exist_ok=True);trace=pilot.Trace(folder/'trace.json');trace.phase='recall';trace.narrative_reasoning_effort='low';trace.narrative_reasoning_budget=None;trace.narrative_max_tokens=12000
 results=[]
 for i,r in enumerate(json.loads((base/'stage-two-v1'/('recall-'+stage+'-assertions-v1')/arm/'answers.json').read_text())):
  oldctx=json.loads(r['narrative_attempts']['progress']['messages'][1]['content']);evidence=pilot.answer_evidence(r['packs'],r['expanded']);binding=oldctx['receiving_binding']
  assert pilot.narrative_recall.supplied_context(r['question'],evidence,binding,'decoded',True)==oldctx, 'Only unchanged input is eligible; new dispatch is forbidden.'
  pending={};checkpoint=folder/f'question-{i}.json'
  try:
   answer=pilot.narrative_recall.answer('deepseek-flash',r['question'],evidence,binding,trace,pending,checkpoint,client.chat,pilot.save,review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded',preserve_citation_receipts=True,clarify_deixis=True)
  except pilot.narrative_recall.NarrativeRejected as e:
   pilot.save(folder/f'rejected-{i}.json',dict(error=str(e),pending=pending));raise
  pilot.verify_narrative_answer(answer,pending,evidence,binding)
  results.append(dict(case_id=r['case_id'],question=r['question'],answer=answer,narrative_attempts=pending['narrative'],source_package_sha256=pilot.digest(dict(question=r['question'],evidence=evidence,binding=binding)),original_answer_index=i))
  pilot.save(folder/'answers.json',results)
 assert len(results)==(5 if stage.endswith('project')else 1)
 print(stage,arm,len(results),'accepted; zero new model dispatches',flush=True)
assert not list((root/'transport').rglob('dispatches/*.json'))
pilot.save(root/'conditions.json',dict(original='Original completed per-transformation target retrievals from stage-two-v1 retained unchanged; exact receipt-context requalification',new_model_calls=0,procedure='original-receipts/v1 opt-in; same generation/review/revision prompts/models/schemas/parameters; fresh per-question budgets, no old verdict or accepted-answer imports',driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),outside_assessment_required=True,stage_two_qualified=False,closing_source_frame_gate_pending=True,source_referents_protocol='report-deixis/v1',world_pointer_protocol='balanced-pointer/v2'))
