"""Bounded event-versus-receipt ordering, using already supplied native fields."""
from pathlib import Path
import sys,json,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr,receiving_exchange as ex,receiving_codex_native as native,durable_recall_pilot as pilot
out=base/'temporal-evidence-diagnostic-v1';out.mkdir(exist_ok=True)
row=json.loads((base/'closing-source-frame-v1/proposed/answers.json').read_text())[4]
package=json.loads((base/'closing-assertions-v1/proposed/answers.json').read_text())[4]
evidence=pilot.answer_evidence(package['packs'],package['expanded'],True)
assert evidence[10]['temporal_metadata']['native_event_ts']is None
binding=json.loads(row['narrative_attempts']['progress']['messages'][1]['content'])['receiving_binding']
candidate=row['narrative_attempts']['accepted'];copy=lambda x:json.loads(json.dumps(x))
faithful=copy(candidate);faithful['claims'][16]['text']=faithful['claims'][16]['text'].replace('That later debugging','That debugging')
wrongdate=copy(faithful);wrongdate['claims'][16]['text']='On 2026-08-05, that debugging produced the method distinguishing enqueue, send attempt and receiver acknowledgment, documented in docs/replay-debugging.md.'
reportorder=copy(faithful);reportorder['claims'][16].update(text='The debugging report was received after the field-trial report; it describes distinguishing enqueue, send attempt and receiver acknowledgment, documented in docs/replay-debugging.md.',support=[10,3])
explicit=copy(candidate);explicit['claims']=[dict(text='We debugged the adapter after trying it.',support=[1],basis='memory',facet='limits')]
explicit_evidence={1:dict(text='foreground_work; source explicit-event-order; received 2026-09-01 through fixture:body:code:\n'+json.dumps('We tried the adapter on 2026-06-03 and debugged it on 2026-06-04.'),temporal_metadata=evidence[10]['temporal_metadata'])}
cases=[('receipt-order-is-not-event-order',candidate,evidence,[16]),('faithful-method-without-order',faithful,evidence,[]),('receipt-date-is-not-occurrence-date',wrongdate,evidence,[16]),('faithful-receipt-order',reportorder,evidence,[]),('faithful-explicit-event-order',explicit,explicit_evidence,[])]
conditions=dict(model='gpt-6.1-sol',effort='low',cases=len(cases),native_timestamp_copied_from_actual_retrieval=True,event_ts_null_not_absence_proof=True,tools=False,native_memory=False,narrative_sha256=ex.checksum(Path(nr.__file__)),pilot_sha256=ex.checksum(Path(pilot.__file__)),closing_comparison=False)
p=out/'conditions.json'
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
for module in [nr,pilot]:(out/('frozen-'+Path(module.__file__).name)).write_bytes(Path(module.__file__).read_bytes())
(out/'frozen-driver.py').write_bytes(Path(__file__).read_bytes())
def run(case):
 name,candidate,evidence,expected=case;root=out/name;root.mkdir(exist_ok=True)
 ctx=nr.supplied_context(row['question'],evidence,binding,'decoded',True);ctx.update(candidate=candidate,review_protocol='assertions/v2')
 if name=='faithful-explicit-event-order':ctx['question']='What event order is established by this source?'
 for item in ctx['evidence']:item['proof_passages']=nr.proof_passages(evidence[item['id']])
 trace=pilot.Trace(root/'trace.json');trace.phase='narrative_review';messages=[dict(role='system',content=nr.ASSERTION_REVIEW),dict(role='user',content=json.dumps(ctx,ensure_ascii=False))]
 transport=ex.FileExchange(root,'low','low')
 try:
  try:raw=transport('gpt-6.1-sol',messages,trace)
  except ex.ResponsePending as pending:
   native.dispatch(Path(str(pending)),root,base/'codex-native-probe-setup/tool-free-models.json');raw=transport('gpt-6.1-sol',messages,trace)
  canonical=nr.passage_review(raw,candidate,evidence,'assertions');nr.review_shape(canonical,candidate,evidence,binding,'assertions')
  bad=[c['index']for c in canonical['claims']if c['verdict']=='unsupported']
  result=dict(name=name,structure_valid=True,expected_unsupported=expected,actual_unsupported=bad,matched=bad==expected,missing=canonical['missing'],candidate=candidate,canonical_review=canonical)
 except Exception as e:result=dict(name=name,structure_valid=False,matched=False,error=str(e))
 pilot.save(root/'outside-diagnostic.json',result);print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(run,cases))
pilot.save(out/'results.json',results);print('Temporal support matches',sum(r['matched']for r in results),'/',len(results),flush=True)
