"""Complete closing packages with the bounded corrected source interpretation."""
from pathlib import Path
import sys,json,hashlib,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot,fictional_model_client as cm
from hermes_cli.auth import read_credential_pool
out=base/'closing-source-frame-v1';out.mkdir(exist_ok=True)
catalog=base/'codex-native-probe-setup/tool-free-models.json';fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json'
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
sources=[base/'closing-receipts-v2/transport',base/'closing-assertions-v1-transport',base/'stage-two-receipts-v2-transport',base/'stage-two-assertions-v1-transport',base/'fresh-flash-pipeline-v5-transport',base/'stage-two-cached-v5-transport',base/'report-referents-diagnostic-v1']
index={}
for source in sources:
 for response in source.rglob('responses/*.json'):index.setdefault(response.name,[]).append(response)
def dispatch(path,root):
 if(out/'stop-dispatch').exists():raise RuntimeError('Stopped corrected closing dispatch; preserve pending work.')
 request=json.loads(path.read_text())
 for response_path in index.get(path.name,[]):
  original=response_path.parent.parent/'requests'/path.name
  if not original.exists()or json.loads(original.read_text())!=request:continue
  response=json.loads(response_path.read_text());receipt=json.loads(Path(response['dispatch_receipt']).read_text())
  if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
  if request['model']=='gpt-6.1-sol':
   if receipt.get('provider')!='openai-codex-native'or receipt.get('reasoning_effort')!='low'or receipt.get('catalog_sha256')!=cm.api.exchange.checksum(catalog):continue
  elif receipt.get('parameters')!=cm.api.parameters(request,'deepseek'):continue
  target=root/'responses'/path.name;target.parent.mkdir(exist_ok=True);pilot.save(target,response);return
 if request['model']=='gpt-6.1-sol':return cm.native.dispatch(path,root,catalog)
 return cm.api.dispatch(path,root,keys[0],'deepseek')
client=cm.Client(out/'transport',fixture,keys[0],catalog,review_protocol='assertions',dispatcher=dispatch)
conditions=dict(driver_sha256=cm.api.exchange.checksum(Path(__file__)),client=json.loads((client.root/'client-conditions.json').read_text()),original_packages='closing-assertions-v1; original formation/retrieval/stress unchanged',source_referents_protocol='report-deixis/v1',world_pointer_protocol='balanced-pointer/v2',native_memory=False,stage_two_complete=False)
p=out/'conditions.json'
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
for name in ['narrative_recall.py','durable_recall_pilot.py','fictional_model_client.py','receiving_exchange.py','receiving_codex_native.py','receiving_text_api.py']:
 target=out/('frozen-'+name);content=(repo/'research/agent-memory-2026-10-06/pilots'/name).read_bytes()
 if target.exists():assert target.read_bytes()==content
 else:target.write_bytes(content)
(out/'frozen-driver.py').write_bytes(Path(__file__).read_bytes())
def run(arm):
 folder=out/arm;folder.mkdir(exist_ok=True);trace=pilot.Trace(folder/'trace.json');trace.phase='recall';trace.narrative_reasoning_effort='low';trace.narrative_reasoning_budget=None;trace.narrative_max_tokens=12000
 results=[]
 for i,r in enumerate(json.loads((base/'closing-assertions-v1'/arm/'answers.json').read_text())):
  old=json.loads(r['narrative_attempts']['progress']['messages'][1]['content']);evidence=pilot.answer_evidence(r['packs'],r['expanded']);binding=old['receiving_binding']
  checkpoint=folder/f'question-{i}.json';pending=json.loads(checkpoint.read_text())if checkpoint.exists()else{}
  try:
   value=pilot.narrative_recall.answer('deepseek-flash',r['question'],evidence,binding,trace,pending,checkpoint,client.chat,pilot.save,review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded',preserve_citation_receipts=True,clarify_deixis=True)
   pilot.verify_narrative_answer(value,pending,evidence,binding)
  except(pilot.narrative_recall.NarrativeRejected,ValueError)as e:
   value=dict(pending['narrative']['generations'][-1],text=' '.join(c['text']for c in pending['narrative']['generations'][-1]['claims']),operational_status='rejected',error=str(e))
  results.append(dict(case_id=r['case_id'],question=r['question'],answer=value,narrative_attempts=pending['narrative'],source_package_sha256=pilot.digest(dict(question=r['question'],evidence=evidence,binding=binding)),original_answer_index=i))
  pilot.save(folder/'answers.json',results)
  print(arm,i,value.get('operational_status','accepted'),'claims',len(value['claims']),flush=True)
 return arm
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,['baseline','proposed']))
print('Complete closing source-frame packages; outside assessment still required.',flush=True)
