from pathlib import Path
import sys,json
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import narrative_recall as nr, durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
fixture=base/'assertion-holdouts.json';out=base/'assertion-holdouts-v1';out.mkdir(exist_ok=True)
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(out/'transport',fixture,keys[0],base/'codex-native-probe-setup/tool-free-models.json',review_protocol='assertions')
binding=dict(being='fictional Ash',receiving_body='fixture:body:voice',same_being_bodies=['fixture:body:code','fixture:body:mobile','fixture:body:voice'],source_network_access=False,repository_runtime_access=False,physical_sensors=False,physical_actuators=False,private_session_access=False)
results=[]
for case in json.loads(fixture.read_text())['cases']:
 root=out/case['id'];root.mkdir(exist_ok=True);source=case['source']
 # Hidden requirements stay outside receiver prompts. Only supplied source and actual question/binding enter answer().
 text=f"{source['role']}; source {source['source']}; received {source['date']} through {source['body']}:\n"+json.dumps(source['text'])
 evidence={1:dict(id=1,text=text)};trace=pilot.Trace(root/'trace.json');trace.phase='recall';checkpoint=root/'pending.json'
 pending=json.loads(checkpoint.read_text())if checkpoint.exists()else{}
 try:result=nr.answer('deepseek-flash',case['question'],evidence,binding,trace,pending,checkpoint,client.chat,pilot.save,review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded')
 except Exception as e:result=dict(error=str(e),qualified=False)
 pilot.save(root/'answer.json',result);results.append(dict(id=case['id'],answer=result));pilot.save(out/'answers.json',results)
 print(case['id'],'finished',result.get('error','candidate accepted; outside grading required'),flush=True)
