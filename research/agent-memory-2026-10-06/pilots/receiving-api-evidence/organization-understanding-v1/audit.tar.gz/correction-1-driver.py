import pathlib,sys,json
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';p=base/'stage-two-v1/pass-1/understanding'
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_organization_pilot as org,durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
client=Client(base/'fresh-flash-pipeline-v4-transport',repo/'docs/benchmarks/narrative-consolidation-cases.json',keys[0],base/'codex-native-probe-setup/tool-free-models.json')
v=org.read(p/'input.json');messages=org.proposal_messages(v,'understanding',1)
messages[1]['content']=json.dumps(dict(**v,organization_pass=1,account_phase='understanding',candidate=org.read(p/'proposal.json'),feedback='Correct the procedural scope under the generic contract: retain the method, source origin and dated illustrative outcomes with evidence pointers; remove repeated event scaffolding and temporary binding inventory. Do not erase source-supported useful meaning. Every summary must retain attribution, as-of dates and unobserved-outcome qualifiers.'),ensure_ascii=False)
bound=p/'correction-bound.json';assert not bound.exists();pilot.save(bound,dict(physical_call_limit=1,semantic_budget_reset=False,original_candidate_preserved=True))
trace=pilot.Trace(p/'proposed/correction-trace.json');trace.phase='consolidation_review'
r=client.chat('deepseek-flash',messages,trace);pilot.save(p/'corrected-proposal.json',r);print(json.dumps(r,ensure_ascii=False,indent=2));print('proposal_sha256',org.digest(r))
