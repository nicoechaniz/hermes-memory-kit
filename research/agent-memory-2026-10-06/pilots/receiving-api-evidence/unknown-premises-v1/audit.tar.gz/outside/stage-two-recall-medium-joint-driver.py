"""Cold fictional recall after a named immutable organization snapshot."""
import sys,pathlib,json,hashlib
repo=pathlib.Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';stage=sys.argv[1]
sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'));sys.path.insert(0,'/home/debian/Projects/hermes-agent')
import durable_recall_pilot as pilot
from fictional_model_client import Client
from hermes_cli.auth import read_credential_pool
qualification_path=base/'closing-medium-joint-v1-outside-ledger.json'
qualification=json.loads(qualification_path.read_text())
assert len(qualification['inspected'])==44 and all(not r['unsupported_claims'] and not r['missing_requirements'] for r in qualification['inspected'].values()), 'Final closing outside gate is required before snapshot dispatch.'
assert all(json.loads((base/'closing-medium-joint-v1'/arm/f'answer-{i}.json').read_text())['answer'].get('operational_status','accepted')=='accepted'for arm in ['baseline','proposed']for i in range(22))
qualification={'outside_ledger_sha256':hashlib.sha256(qualification_path.read_bytes()).hexdigest(),'answers':44,'profile':'Flash-low / native Sol-low correction / native Sol-medium verification'}
fixture=repo/'docs/benchmarks/narrative-consolidation-cases.json';source=base/'stage-two-v1'/('source-'+stage);assert source.is_dir()
keys=[r['access_token']for r in read_credential_pool('deepseek')if r.get('source')=='manual'and r.get('access_token')];assert len(keys)==1
import fictional_model_client as client_module
def completed_exact_dispatch(path,root):
 request=json.loads(path.read_text());sources=[base/'stage-two-medium-joint-v1-transport',base/'closing-medium-joint-v1/transport',base/'closing-temporal-source-v1/transport',base/'closing-receipts-v2/transport',base/'closing-assertions-v1-transport',base/'stage-two-receipts-v2-transport',base/'stage-two-assertions-v1-transport',base/'fresh-flash-pipeline-v5-transport',base/'stage-two-cached-v5-transport']
 if (base/'stage-two-medium-joint-v1-transport/stop-dispatch').exists():raise RuntimeError('Human-directed foreground stop; preserve this pending request.')
 for source in sources:
  for response_path in source.rglob('responses/'+path.name):
   if response_path.parent.parent.resolve()==root.resolve():continue
   request_path=response_path.parent.parent/'requests'/path.name
   if not request_path.exists()or json.loads(request_path.read_text())!=request:continue
   response=json.loads(response_path.read_text());receipt_path=pathlib.Path(response['dispatch_receipt']);receipt=json.loads(receipt_path.read_text())
   if receipt.get('state')!='completed'or receipt.get('content')!=response.get('content')or receipt.get('request_sha256')!=path.stem:continue
   if request['model']=='gpt-6.1-sol':
    if receipt.get('provider')!='openai-codex-native'or receipt.get('requested_model')!=request['model']or receipt.get('reasoning_effort')!=request['reasoning_effort']or receipt.get('catalog_sha256')!=hashlib.sha256((base/'codex-native-probe-setup/tool-free-models.json').read_bytes()).hexdigest():continue
   elif receipt.get('parameters')!=client_module.api.parameters(request,'deepseek'):continue
   target=root/'responses'/path.name;target.parent.mkdir(exist_ok=True);pilot.save(target,response)
   return
 if request['model']=='gpt-6.1-sol':return client_module.native.dispatch(path,root,base/'codex-native-probe-setup/tool-free-models.json')
 return client_module.api.dispatch(path,root,keys[0],'deepseek')
client=Client(base/'stage-two-medium-joint-v1-transport'/stage,fixture,keys[0],base/'codex-native-probe-setup/tool-free-models.json',review_protocol='assertions',review_effort='medium',dispatcher=completed_exact_dispatch);pilot.chat=client.chat
original=pilot.narrative_recall.answer
def answer(*args,**kwargs):
 kwargs.update(review_model='gpt-6.1-sol',revision_model='gpt-6.1-sol',review_protocol='assertions',source_representation='decoded',preserve_citation_receipts=True,clarify_deixis=True,allow_joint_support=True,review_effort='medium');return original(*args,**kwargs)
pilot.narrative_recall.answer=answer
original_evidence=pilot.answer_evidence
def answer_evidence(packs,expanded,include_temporal_metadata=False):return original_evidence(packs,expanded,True)
pilot.answer_evidence=answer_evidence
out=base/'stage-two-v1'/('recall-'+stage+'-medium-joint-v1')
p=out.with_name(out.name+'-driver-conditions.json');conditions=dict(driver_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),source=stage,qualification=qualification,closing_narrative_qualification=True,stage_two_complete=False,joint_support_protocol='memory-and-binding/v1',review_effort='medium',temporal_evidence_protocol='native-timestamp-with-receipt-scope/v1',client_conditions=json.loads((client.root/'client-conditions.json').read_text()),raw_response_reuse='Only exact complete identical fictional requests with unchanged actual role parameters and validated physical receipts across these fictional transport roots. No accepted answers/checkpoints, verdict approval or repair-budget imports; every response consumed and evaluated anew; new dispatches are explicit and separately counted.')
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
sys.argv=['durable_recall_pilot','--out',str(out),'--model','deepseek-flash','--receiving-model','deepseek-flash','--corpus',str(fixture),'--review-capture','--narrative','--narrative-reasoning-effort','low','--narrative-reasoning-budget','none','--complete-diagnostics','--reuse-capture',str(source),'--reuse-with-retrieval-upgrade']+sys.argv[2:]
# The control has not undergone organization or correction. Reuse its qualified
# observation only after proving every source table/vector/provenance is equal;
# it is explicitly a reference, never a new dispatch or response checkpoint.
for name in ['narrative_recall.py','durable_recall_pilot.py','fictional_model_client.py','receiving_exchange.py','receiving_codex_native.py','receiving_text_api.py']:
 target=client.root/('frozen-'+name);content=(repo/'research/agent-memory-2026-10-06/pilots'/name).read_bytes()
 if target.exists():assert target.read_bytes()==content
 else:target.write_bytes(content)
(client.root/'frozen-stage-driver.py').write_bytes(pathlib.Path(__file__).read_bytes())
original_run_variant=pilot.run_variant
def run_variant(name,guidance,args,corpus):
 if name!='baseline':return original_run_variant(name,guidance,args,corpus)
 invariant_path=base/'baseline-stage-invariance-candidate.json'
 invariant=json.loads(invariant_path.read_text());assert invariant['all_equal']
 expected=next(r for r in invariant['rows']if r['path']==str((source/'baseline/memory/library.db').relative_to(base)))
 import sqlite3
 db=source/'baseline/memory/library.db';assert hashlib.sha256(db.read_bytes()).hexdigest()==expected['file_sha256']
 cases=set(args.recall_case);originals=json.loads((base/'closing-assertions-v1/baseline/answers.json').read_text())
 indices=[i for i,r in enumerate(originals)if not cases or r['case_id']in cases]
 reference=dict(scope='Unchanged baseline source: reuse qualified closing control observation, not new receiving work.',source_database_sha256=expected['file_sha256'],invariance_sha256=hashlib.sha256(invariant_path.read_bytes()).hexdigest(),same_semantic_tables_sha256=expected['semantic_tables_sha256'],qualified_closing_ledger_sha256=qualification['outside_ledger_sha256'],qualified_answers={i:qualification and json.loads(qualification_path.read_text())['inspected'][f'baseline/{i}']['answer_sha256'] for i in indices},new_calls=0,new_embeddings=0)
 (out/'baseline').mkdir(parents=True,exist_ok=True);pilot.save(out/'baseline/reference.json',reference)
 result=json.loads((base/'closing-assertions-v1/results.json').read_text())[0]
 return dict(result,questions=len(indices),llm_calls=0,rejected_narratives=0,qualified_result_reuse=True,reference='baseline/reference.json')
pilot.run_variant=run_variant
pilot.main()
