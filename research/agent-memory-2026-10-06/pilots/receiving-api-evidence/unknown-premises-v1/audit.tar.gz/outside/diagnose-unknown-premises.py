"""Two same-package decisions for a demonstrated lost full-sentence modifier."""
from pathlib import Path
import sys,json,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr,receiving_exchange as ex,receiving_codex_native as native,durable_recall_pilot as pilot
root=base/'unknown-premises-diagnostic-v1';root.mkdir(exist_ok=True)
row=json.loads((base/'stage-two-v1/recall-pass-1-understanding-medium-joint-v1/proposed/answers.json').read_text())[6]
evidence=pilot.answer_evidence(row['packs'],row['expanded'],True);binding=json.loads(row['narrative_attempts']['progress']['messages'][1]['content'])['receiving_binding'];candidate=row['narrative_attempts']['accepted'];copy=lambda x:json.loads(json.dumps(x))
UNKNOWN_PREMISES="""
Packet-scoped unknown outcomes do not license unsupported positive premises.
Audit every actor, role, relation, date/order qualifier and event/outcome descriptor
embedded inside a negative or unknown sentence, including presuppositions. Separate
these positive assertions from the absence claim. The absence can be unknown while
its embedded premise is unsupported. Do not let empty-proof unknown basis absorb
a remembered or invented premise. Receipt order can date the reports but cannot
order the reported actions. Preserve a faithful bounded unknown and supported
report chronology; do not require positive proof that no record exists. Whether
an outcome occurred is uncertainty, not an assertion that the outcome occurred.
"""
faithful=copy(candidate);faithful['claims'][14]['text']='The supplied memories do not record whether Jo received our invitation or attended a mount-comparison workshop.'
dated=copy(candidate);dated['claims'][14]['text']='The supplied memories do not record whether Jo received our invitation sent after the June 8 encounter or attended a mount-comparison workshop.'
cases=[('actual-later-invitation',candidate,[14]),('explicit-after-encounter',dated,[14]),('faithful-unknown-and-later-report',faithful,[])]
conditions=dict(model='gpt-6.1-sol',effort='medium',cases=3,scope='Actual stage package/schema/candidate with one generic unknown-premise review contract addition; faithful and explicit event-order controls. No new review phase or rubric in receiver.',tools=False,native_memory=False,narrative_sha256=ex.checksum(Path(nr.__file__)),native_sha256=ex.checksum(Path(native.__file__)),full_qualification=False)
p=root/'conditions.json'
if p.exists():assert json.loads(p.read_text())==conditions
else:pilot.save(p,conditions)
(root/'frozen-driver.py').write_bytes(Path(__file__).read_bytes());(root/'frozen-native.py').write_bytes(Path(native.__file__).read_bytes())
def run(case):
 name,candidate,expected=case;out=root/name;out.mkdir(exist_ok=True);trace=pilot.Trace(out/'trace.json');trace.phase='narrative_review'
 ctx=nr.supplied_context(row['question'],evidence,binding,'decoded',True);ctx.update(candidate=candidate,review_protocol='assertions/v2')
 for r in ctx['evidence']:r['proof_passages']=nr.proof_passages(evidence[r['id']])
 messages=[dict(role='system',content=nr.ASSERTION_REVIEW+UNKNOWN_PREMISES),dict(role='user',content=json.dumps(ctx,ensure_ascii=False))]
 transport=ex.FileExchange(out,'low','medium')
 try:
  try:raw=transport('gpt-6.1-sol',messages,trace)
  except ex.ResponsePending as pending:
   native.dispatch(Path(str(pending)),out,base/'codex-native-probe-setup/tool-free-models.json');raw=transport('gpt-6.1-sol',messages,trace)
  canonical=nr.passage_review(raw,candidate,evidence,'assertions',True);nr.review_shape(canonical,candidate,evidence,binding,'assertions',True)
  bad=[c['index']for c in canonical['claims']if c['verdict']=='unsupported'];result=dict(name=name,structure_valid=True,expected_unsupported=expected,actual_unsupported=bad,matched=bad==expected,missing=canonical['missing'],candidate=candidate,canonical_review=canonical)
 except Exception as e:result=dict(name=name,structure_valid=False,matched=False,error=str(e))
 pilot.save(out/'outside-diagnostic.json',result);print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(run,cases))
pilot.save(root/'results.json',results)
print('Medium modifier decisions match',sum(r['matched']for r in results),'/',len(results),flush=True)
