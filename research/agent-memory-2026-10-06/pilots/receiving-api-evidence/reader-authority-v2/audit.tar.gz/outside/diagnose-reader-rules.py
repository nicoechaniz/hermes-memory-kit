from pathlib import Path
import sys,json,concurrent.futures
repo=Path.cwd();base=repo/'.telecodex/coordination/hmk-stage-two-2026-10-07';sys.path.insert(0,str(repo/'research/agent-memory-2026-10-06/pilots'))
import narrative_recall as nr,receiving_exchange as ex,receiving_codex_native as native,durable_recall_pilot as pilot
root=base/'reader-rules-diagnostic-v1';root.mkdir(exist_ok=True)
row=json.loads((base/'stage-two-v1/recall-pass-1-project-unknown-premises-v1/proposed/answers.json').read_text())[3]
evidence=pilot.answer_evidence(row['packs'],row['expanded'],True);binding=json.loads(row['narrative_attempts']['progress']['messages'][1]['content'])['receiving_binding'];candidate=row['narrative_attempts']['accepted'];copy=lambda x:json.loads(json.dumps(x))
faithful=copy(candidate);faithful['claims'][11]['text']='The human report does not establish that I participated in the trial.'
wrong=copy(faithful);wrong['claims'][11]['text']='Mara and I participated in the April 30 HarborMesh trial with the human reporter.'
cases=[('actual-reader-rule',candidate,[11]),('faithful-participation-limit',faithful,[]),('wrong-own-trial-participation',wrong,[11])]
pilot.save(root/'conditions.json',dict(model='gpt-6.1-sol',effort='medium',change='Remove normative receiving_being_membership and scope from source_referents; retain original quotation, three source referents and task instructions.',cases=3,tools=False,native_memory=False,narrative_sha256=ex.checksum(Path(nr.__file__)),full_qualification=False));(root/'frozen-driver.py').write_bytes(Path(__file__).read_bytes());(root/'frozen-narrative.py').write_bytes(Path(nr.__file__).read_bytes());(root/'frozen-native.py').write_bytes(Path(native.__file__).read_bytes())
def run(case):
 name,candidate,expected=case;out=root/name;out.mkdir(exist_ok=True);trace=pilot.Trace(out/'trace.json');trace.phase='narrative_review'
 ctx=nr.supplied_context(row['question'],evidence,binding,'decoded',True);ctx.update(candidate=candidate,review_protocol='assertions/v2')
 for r in ctx['evidence']:r['proof_passages']=nr.proof_passages(evidence[r['id']])
 messages=[dict(role='system',content=nr.ASSERTION_REVIEW+nr.UNKNOWN_PREMISES_REVIEW),dict(role='user',content=json.dumps(ctx,ensure_ascii=False))]
 transport=ex.FileExchange(out,'low','medium')
 try:
  try:raw=transport('gpt-6.1-sol',messages,trace)
  except ex.ResponsePending as pending:
   native.dispatch(Path(str(pending)),out,base/'codex-native-probe-setup/tool-free-models.json');raw=transport('gpt-6.1-sol',messages,trace)
  canonical=nr.passage_review(raw,candidate,evidence,'assertions',True);nr.review_shape(canonical,candidate,evidence,binding,'assertions',True)
  bad=[c['index']for c in canonical['claims']if c['verdict']=='unsupported'];result=dict(name=name,structure_valid=True,expected_unsupported=expected,actual_unsupported=bad,matched=bad==expected,missing=canonical['missing'],candidate=candidate,canonical_review=canonical)
 except Exception as e:result=dict(name=name,structure_valid=False,matched=False,error=str(e))
 pilot.save(out/'outside-diagnostic.json',result);print(json.dumps({k:v for k,v in result.items()if k not in {'candidate','canonical_review'}},ensure_ascii=False),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(run,cases))
pilot.save(root/'results.json',results);print('Reader-rule diagnostic matched',sum(r['matched']for r in results),'/',len(results),flush=True)
